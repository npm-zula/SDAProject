package HSMS.DBHandlers;

import HSMS.Applicant;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class ApplicantDBHandler {


    public void saveApplicant(Applicant applicant){
        String sql = "insert into Applicant (FirstName, LastName, cnic, EmailAddress) VALUES(?, ?, ?, ?)";
        try {
            String url = "jdbc:jtds:sqlserver://ZULA:1433/newHSMS;instance=SQLEXPRESS";
            //String url ="jdbc:sqlserver://ZULA:1433;databaseName=HSMS;integratedSecurity=true";
            Connection conn = DriverManager.getConnection(url,"User","qwerty");
            PreparedStatement st = conn.prepareStatement(sql);
            //st.executeUpdate("INSERT INTO Applicant " + "VALUES (fname, lname, cnic, email)");
            st.setString(1,applicant.getFirstName());
            st.setString(2, applicant.getLastName());
            st.setString(3, String.valueOf(applicant.getCnic()));
            st.setString(4, applicant.getEmailAddress());
            st.executeUpdate();
            conn.close();
        } catch (Exception e) {
            System.err.println("Got an exception! ");
            System.err.println(e.getMessage());
        }
    }
}
