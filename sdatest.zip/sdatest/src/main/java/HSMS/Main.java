package HSMS;

import HSMS.ApplicationTypes.Application;

import static HSMS.HSMS.getHsms;

public class Main {

    public static void main(String[] args) {
        //ApplicationDBhandler a = new ApplicationDBhandler();


//        HSMS h = new HSMS();
//
//        System.out.println("HELLO WORLD");
//
//        Applicant a = h.createApplicant("ali","butt",123123454,"ehti.lawa@gmail.com",false);
//
//        Application aa = h.propertyRegistrationApplication(a, "34", "10 marla","Aashir","Aftab",43,123124,"asdasd@gmail.com" );
//
//        System.out.println(aa.toString());
    }
}
