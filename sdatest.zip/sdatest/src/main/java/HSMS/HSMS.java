package HSMS;

import HSMS.ApplicationTypes.*;
import HSMS.Complaint.ComplaintRecords;

import static HSMS.Applicant.getApplicantdata;

public class HSMS {

    private static HSMS hsms = null;
//    Application regApplication = new RegistrationApplication();
//    Application oTApplication = new OwnerTransferApplication();
//    Application rentingApplication = new RentingApplication();
//    Application EtagApplication = new EtagApplication();
    ApplicationRecords applicationRecords = new ApplicationRecords();
    ComplaintRecords complaintRecords = new ComplaintRecords();


    public static HSMS getHsms(){
        if(hsms == null){
            hsms = new HSMS();
        }
        return hsms;
    }


    public Applicant createApplicant(String fname, String lname, int cnic, String email, boolean check){
        if(!check)
            return getApplicantdata().applicantCreation(fname, lname, cnic,email);
        else
          return getApplicantdata().applicantCreation(fname, lname,cnic,email,check);
    }

    public Application propertyRegistrationApplication(int ApplicationNo,String houseNo, String size, String oFName, String oLName, int oAge, int oCnic){
      return  applicationRecords.createRegApplication(ApplicationNo,houseNo,size,oFName,oLName,oAge,oCnic);
    }

    public Application propertyTransApplication(Applicant applicant,String RFName, String RLName, int RCNIC, String oFName, String oLName,  int oCnic){
        return  applicationRecords.createTransferApplication(applicant,RFName,RLName,RCNIC,oFName,oLName,oCnic);
    }
    public Application propertyRentingApplication(Applicant applicant,String RFName, String RLName, int RCNIC, String oFName, String oLName,  int oCnic, int rent, int increment){
        return  applicationRecords.createRentApplication(applicant,RFName,RLName,RCNIC,oFName,oLName,oCnic, rent, increment);
    }

    public Application etagApplication(Applicant applicant, String oFName, String oLName, int oCnic, String vNo, String vType, String vYear, String vMake, int vEngineSize, boolean others){
        return  applicationRecords.createEtagApplication(applicant,oFName,oLName,oCnic,vNo,vType,vYear,vMake,vEngineSize,others);
    }

    public Application getApplicationStatus(int appID){
            return applicationRecords.getApplication(appID);
    }

    public void complaintRegistration(String HouseNo, String problem, String email){
            complaintRecords.launchComplaint(HouseNo, problem, email);
    }

}
