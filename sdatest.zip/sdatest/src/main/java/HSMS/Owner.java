package HSMS;

public class Owner {
    private String firstName;
    private String lastName;
    private int age;
    private double cNIC;
    private String emailAddress;

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public int getAge() {
        return age;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public double getcNIC() {
        return cNIC;
    }

    public void setcNIC(double cNIC) {
        this.cNIC = cNIC;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
