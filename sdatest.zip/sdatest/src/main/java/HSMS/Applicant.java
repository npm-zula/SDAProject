package HSMS;

import HSMS.ApplicationTypes.Application;
import HSMS.DBHandlers.ApplicantDBHandler;

import java.util.HashMap;

public class Applicant {

    private String firstName;
    private String lastName;
    private int cnic;
    private String emailAddress;
   // private HashMap<Integer,Applicant> applicantHashMap = new HashMap<>();
    ApplicantDBHandler db = new ApplicantDBHandler();

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getCnic() {
        return cnic;
    }

    public void setCnic(int cnic) {
        this.cnic = cnic;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public Applicant(String firstName, String lastName, int cnic, String emailAddress) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.cnic = cnic;
        this.emailAddress = emailAddress;
    }
    Applicant(){

    }


    // SINGLETON
    static Applicant app = null;

    public static Applicant getApplicantdata(){

        if(app == null){
            app = new Applicant();
        }
        return app;
    }


    public Applicant applicantCreation(String fname, String lname, int cninc, String email){
        Applicant temp = new Applicant(fname,lname,cninc,email);
       // db.saveApplicant(temp);

        return temp;
    }

    public Applicant applicantCreation(String fname, String lname, int cninc, String email, boolean check){
        // owner DBHandler check if applicant cnic  ==  registered owner CNIC



//        public static ArrayList<Customer> getAllCustomer() throws ClassNotFoundException, SQLException {
//            Connection conn=DBConnection.getDBConnection().getConnection();
//            Statement stm;
//            stm = conn.createStatement();
//            String sql = "Select * From Customer";
//            ResultSet rst;
//            rst = stm.executeQuery(sql);
//            ArrayList<Customer> customerList = new ArrayList<>();
//            while (rst.next()) {
//                Customer customer = new Customer(rst.getString("id"), rst.getString("name"), rst.getString("address"), rst.getDouble("salary"));
//                customerList.add(customer);
//            }
//            return customerList;
//        }

        Applicant temp = new Applicant(fname,lname,cninc,email);
        db.saveApplicant(temp);

        return temp;
    }


}
