package com.example.sdatest;

import HSMS.HSMS;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class ResidentController {

    private Stage stage;
    private Scene scene;
    private Parent root;

    private Scene preScene;

    public void setPreScene(Scene preScene) {
        this.preScene = preScene;
    }

    @FXML
    public void BackBtn(ActionEvent actionEvent) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Resident/ResidentDashboard.fxml"));
        stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void MenuBtn(ActionEvent actionEvent) throws IOException {
        root = FXMLLoader.load(getClass().getResource("dashboard.fxml"));
        stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void ApplyRent(ActionEvent actionEvent) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Resident/ResidentRentingApplication.fxml"));
        stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);

        stage.setScene(scene);
        stage.show();

    }
    @FXML
    public void TransferProperty(ActionEvent actionEvent) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Resident/ResidentOwnershipTransfer.fxml"));
        stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void EtagApplication(ActionEvent actionEvent) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Resident/EtagApplication.fxml"));
        stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void Complaints(ActionEvent actionEvent) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Resident/ResidentComplaintReg.fxml"));
        stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }



}
